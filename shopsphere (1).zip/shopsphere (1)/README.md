# ShopSphere – Mini E-Commerce Store

## Project Description

ShopSphere is a frontend-only mini e-commerce application built with React.js. Users can browse a curated product catalog, search and filter products, view details, manage a shopping cart, and complete a simulated checkout. The cart persists across page refreshes using localStorage. This project demonstrates core React concepts in a polished, portfolio-ready application.

## Features

- Product catalog with 16 realistic products
- Product search by name
- Category filtering (Electronics, Fashion, Home, Accessories)
- Product sorting (price, name, rating)
- Product details page with quantity selector
- Shopping cart with add, increase, decrease, and remove
- Dynamic cart totals and item count badge
- React Router navigation (no page refresh)
- localStorage cart persistence
- Responsive design (desktop, tablet, mobile)
- Simulated checkout with form validation
- Empty cart and error states
- 404 Not Found page

## Technologies

- React.js (functional components only)
- JavaScript
- Vite
- React Router DOM
- HTML5
- CSS3
- localStorage

## React Concepts Demonstrated

- **Components** – Reusable UI pieces (Navbar, ProductCard, CartItem, etc.)
- **Props** – Parent → child data flow (cart state, handlers, product data)
- **useState** – Cart, search, filters, sort, quantity, form state, mobile menu
- **useEffect** – Load/save cart to localStorage
- **Event handling** – onClick, onChange, onSubmit
- **Controlled forms** – Checkout form with value + onChange + validation
- **Conditional rendering** – Empty cart, no results, product not found, success screen
- **List rendering** – `.map()` for products, cart items, categories with unique `key`s
- **React Router** – Multi-page navigation with `BrowserRouter`, `Routes`, `Route`, `Link`, `NavLink`, `useParams`

## Installation

```bash
# Clone or navigate to the project folder
cd shopsphere-app

# Install dependencies
npm install

# Start the development server
npm run dev
```

Open the URL shown in the terminal (usually `http://localhost:5173`).

## Project Structure

```
src/
├── components/
│   ├── Navbar.jsx          # Top navigation with cart badge & mobile menu
│   ├── Footer.jsx          # Site footer
│   ├── ProductCard.jsx     # Reusable product card
│   ├── SearchBar.jsx       # Controlled search input
│   ├── CategoryFilter.jsx  # Category filter buttons
│   ├── SortDropdown.jsx    # Sort select dropdown
│   ├── CartItem.jsx        # Single cart line item
│   ├── CartSummary.jsx     # Order summary (subtotal, shipping, total)
│   └── EmptyCart.jsx       # Empty cart state
├── pages/
│   ├── Home.jsx            # Hero + featured categories & products
│   ├── Products.jsx        # Full catalog with search/filter/sort
│   ├── ProductDetails.jsx  # Single product view
│   ├── Cart.jsx            # Shopping cart page
│   ├── Checkout.jsx        # Checkout form + order confirmation
│   └── NotFound.jsx        # 404 page
├── data/
│   └── products.js         # Mock product data (16 items)
├── App.jsx                 # Root: cart state, routing, layout
├── main.jsx                # Entry point
├── App.css                 # Component & layout styles
└── index.css               # Global styles & design tokens
```

## Screenshots

![Home Page](screenshots/home.png)
![Product Catalog](screenshots/products.png)
![Shopping Cart](screenshots/cart.png)

## Known Limitations

- No backend – product data is local/mock
- No user authentication
- No real payment processing (checkout is simulated)
- Images loaded from external URLs (Unsplash)

## Future Improvements

- Backend API integration
- User accounts and authentication
- Real payment gateway
- Order history
- Product reviews and ratings submission
- Wishlist feature
- Image upload for products (admin)
