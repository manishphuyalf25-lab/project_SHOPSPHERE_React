import { Link } from 'react-router-dom';
import CartItem from '../components/CartItem';
import CartSummary from '../components/CartSummary';
import EmptyCart from '../components/EmptyCart';

function Cart({ cart, onIncrease, onDecrease, onRemove }) {
  if (cart.length === 0) {
    return (
      <div className="cart-page">
        <div className="container">
          <EmptyCart />
        </div>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <div className="container">
        <header className="page-header">
          <h1>Shopping Cart</h1>
          <p>{cart.reduce((sum, item) => sum + item.quantity, 0)} item(s) in your cart</p>
        </header>

        <div className="cart-layout">
          <div className="cart-items">
            {cart.map((item) => (
              <CartItem
                key={item.id}
                item={item}
                onIncrease={onIncrease}
                onDecrease={onDecrease}
                onRemove={onRemove}
              />
            ))}
          </div>

          <aside className="cart-sidebar">
            <CartSummary cart={cart} />
            <Link to="/products" className="btn btn-outline btn-block continue-shopping">
              Continue Shopping
            </Link>
          </aside>
        </div>
      </div>
    </div>
  );
}

export default Cart;
