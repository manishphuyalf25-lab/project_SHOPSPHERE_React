import { useState, useMemo } from 'react';
import products from '../data/products';
import ProductCard from '../components/ProductCard';
import SearchBar from '../components/SearchBar';
import CategoryFilter from '../components/CategoryFilter';
import SortDropdown from '../components/SortDropdown';

function Products({ onAddToCart }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('default');

  const categories = ['All', ...new Set(products.map((p) => p.category))];

  const filteredAndSorted = useMemo(() => {
    let result = [...products];

    // Filter by search term
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase().trim();
      result = result.filter((p) =>
        p.name.toLowerCase().includes(term)
      );
    }

    // Filter by category
    if (selectedCategory !== 'All') {
      result = result.filter((p) => p.category === selectedCategory);
    }

    // Sort
    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'name-asc':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'name-desc':
        result.sort((a, b) => b.name.localeCompare(a.name));
        break;
      case 'rating-desc':
        result.sort((a, b) => b.rating - a.rating);
        break;
      default:
        // Keep original order
        break;
    }

    return result;
  }, [searchTerm, selectedCategory, sortBy]);

  return (
    <div className="products-page">
      <div className="container">
        <header className="page-header">
          <h1>Our Products</h1>
          <p>Discover quality products you'll love</p>
        </header>

        <div className="filters-bar">
          <SearchBar
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
          />
          <div className="filters-row">
            <CategoryFilter
              categories={categories}
              selectedCategory={selectedCategory}
              onCategoryChange={setSelectedCategory}
            />
            <SortDropdown
              sortBy={sortBy}
              onSortChange={setSortBy}
            />
          </div>
        </div>

        {filteredAndSorted.length === 0 ? (
          <div className="no-results">
            <p>No products found matching your criteria.</p>
            <button
              type="button"
              className="btn btn-outline"
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('All');
                setSortBy('default');
              }}
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <>
            <p className="results-count">
              Showing {filteredAndSorted.length} product{filteredAndSorted.length !== 1 ? 's' : ''}
            </p>
            <div className="products-grid">
              {filteredAndSorted.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={onAddToCart}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default Products;
