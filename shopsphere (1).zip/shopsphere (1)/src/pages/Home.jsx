import { Link } from 'react-router-dom';
import products from '../data/products';
import ProductCard from '../components/ProductCard';

function Home({ onAddToCart }) {
  const featuredProducts = products.slice(0, 4);
  const categories = [
    { name: 'Electronics', icon: '💻', desc: 'Gadgets & devices' },
    { name: 'Fashion', icon: '👕', desc: 'Style essentials' },
    { name: 'Home', icon: '🏠', desc: 'Living comfort' },
    { name: 'Accessories', icon: '👜', desc: 'Finishing touches' },
  ];

  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <h1 className="hero-title">Shop smarter. Live better.</h1>
          <p className="hero-subtitle">
            Explore our curated collection of quality products at great prices.
          </p>
          <div className="hero-actions">
            <Link to="/products" className="btn btn-primary btn-lg">
              Shop Now
            </Link>
            <Link to="/products" className="btn btn-outline btn-lg">
              Explore Products
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="section categories-section">
        <div className="container">
          <h2 className="section-title">Shop by Category</h2>
          <div className="categories-grid">
            {categories.map((cat) => (
              <Link
                key={cat.name}
                to="/products"
                className="category-card"
              >
                <span className="category-icon" aria-hidden="true">{cat.icon}</span>
                <h3>{cat.name}</h3>
                <p>{cat.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="section featured-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Featured Products</h2>
            <Link to="/products" className="section-link">
              View All →
            </Link>
          </div>
          <div className="products-grid">
            {featuredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container">
          <h2>Ready to find your next favorite product?</h2>
          <p>Browse our full catalog and discover quality items at great prices.</p>
          <Link to="/products" className="btn btn-primary btn-lg">
            Browse All Products
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Home;
