const products = [
  {
    id: 1,
    name: "Wireless Bluetooth Headphones",
    price: 89.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1505740420928-617708665b33?w=400&h=400&fit=crop",
    description: "Premium wireless headphones with active noise cancellation, 30-hour battery life, and crystal-clear sound quality. Perfect for music lovers and professionals on the go.",
    rating: 4.5,
    stock: 25
  },
  {
    id: 2,
    name: "Smart Fitness Watch",
    price: 149.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop",
    description: "Track your fitness goals with this advanced smartwatch. Features heart rate monitoring, GPS, sleep tracking, and 7-day battery life. Water-resistant design.",
    rating: 4.7,
    stock: 18
  },
  {
    id: 3,
    name: "Minimalist Leather Wallet",
    price: 39.99,
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=400&h=400&fit=crop",
    description: "Slim and stylish genuine leather wallet with RFID protection. Holds up to 8 cards and cash. Perfect everyday essential for modern professionals.",
    rating: 4.3,
    stock: 40
  },
  {
    id: 4,
    name: "Classic Cotton T-Shirt",
    price: 24.99,
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1521572163474-6854f9bf17fc?w=400&h=400&fit=crop",
    description: "Soft, breathable 100% organic cotton t-shirt. Available in multiple colors. Comfortable fit for everyday wear with a modern silhouette.",
    rating: 4.4,
    stock: 60
  },
  {
    id: 5,
    name: "Ceramic Coffee Mug Set",
    price: 34.99,
    category: "Home",
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=400&h=400&fit=crop",
    description: "Set of 4 handcrafted ceramic mugs. Microwave and dishwasher safe. Elegant design that elevates your morning coffee experience.",
    rating: 4.6,
    stock: 30
  },
  {
    id: 6,
    name: "Aromatherapy Diffuser",
    price: 49.99,
    category: "Home",
    image: "https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400&h=400&fit=crop",
    description: "Ultrasonic essential oil diffuser with 7 LED light colors. Creates a calming atmosphere in any room. Auto shut-off and large water capacity.",
    rating: 4.5,
    stock: 22
  },
  {
    id: 7,
    name: "Leather Crossbody Bag",
    price: 79.99,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400&h=400&fit=crop",
    description: "Stylish genuine leather crossbody bag with adjustable strap. Multiple compartments for organization. Perfect for daily use or travel.",
    rating: 4.8,
    stock: 15
  },
  {
    id: 8,
    name: "Polarized Sunglasses",
    price: 59.99,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=400&h=400&fit=crop",
    description: "UV400 protection polarized sunglasses with lightweight frames. Stylish design suitable for both men and women. Includes protective case.",
    rating: 4.4,
    stock: 35
  },
  {
    id: 9,
    name: "Portable Bluetooth Speaker",
    price: 69.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=400&fit=crop",
    description: "Waterproof portable speaker with powerful bass and 12-hour playtime. Connects via Bluetooth 5.0. Ideal for outdoor adventures and parties.",
    rating: 4.6,
    stock: 28
  },
  {
    id: 10,
    name: "Wool Blend Scarf",
    price: 29.99,
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?w=400&h=400&fit=crop",
    description: "Soft wool blend scarf in classic patterns. Warm and cozy for cold weather. Versatile accessory that complements any outfit.",
    rating: 4.2,
    stock: 45
  },
  {
    id: 11,
    name: "Stainless Steel Water Bottle",
    price: 32.99,
    category: "Home",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&h=400&fit=crop",
    description: "Insulated stainless steel bottle keeps drinks cold for 24 hours or hot for 12 hours. Leak-proof design with 750ml capacity. BPA-free.",
    rating: 4.7,
    stock: 50
  },
  {
    id: 12,
    name: "Wireless Charging Pad",
    price: 29.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1586953208448-b95a79781f91?w=400&h=400&fit=crop",
    description: "Fast wireless charging pad compatible with all Qi-enabled devices. Sleek minimalist design with LED indicator. Supports up to 15W charging.",
    rating: 4.3,
    stock: 32
  },
  {
    id: 13,
    name: "Denim Jacket",
    price: 89.99,
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=400&h=400&fit=crop",
    description: "Classic denim jacket with a modern fit. Durable construction with comfortable stretch. Perfect layering piece for any season.",
    rating: 4.5,
    stock: 20
  },
  {
    id: 14,
    name: "Desk Organizer Set",
    price: 27.99,
    category: "Home",
    image: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=400&h=400&fit=crop",
    description: "Bamboo desk organizer with multiple compartments. Keep your workspace tidy and stylish. Includes pen holder, tray, and note stand.",
    rating: 4.4,
    stock: 38
  },
  {
    id: 15,
    name: "Leather Belt",
    price: 44.99,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1624222247344-550fb60583fd?w=400&h=400&fit=crop",
    description: "Genuine leather belt with classic buckle. Available in multiple sizes. Timeless accessory for both casual and formal wear.",
    rating: 4.6,
    stock: 42
  },
  {
    id: 16,
    name: "Noise Cancelling Earbuds",
    price: 119.99,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&h=400&fit=crop",
    description: "True wireless earbuds with active noise cancellation and transparency mode. 8-hour battery life plus 24 hours from the case. Premium sound quality.",
    rating: 4.8,
    stock: 16
  }
];

export default products;
