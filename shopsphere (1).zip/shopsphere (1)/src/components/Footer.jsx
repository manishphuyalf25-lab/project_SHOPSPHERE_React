import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-grid">
          <div className="footer-brand">
            <h3 className="footer-logo">
              <span className="brand-icon">◈</span> ShopSphere
            </h3>
            <p className="footer-tagline">Discover products you'll love.</p>
            <p className="footer-desc">
              A curated selection of quality products at great prices. Shop smarter, live better.
            </p>
          </div>

          <div className="footer-links">
            <h4>Quick Links</h4>
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/products">Products</Link></li>
              <li><Link to="/cart">Cart</Link></li>
              <li><Link to="/checkout">Checkout</Link></li>
            </ul>
          </div>

          <div className="footer-links">
            <h4>Categories</h4>
            <ul>
              <li><Link to="/products">Electronics</Link></li>
              <li><Link to="/products">Fashion</Link></li>
              <li><Link to="/products">Home</Link></li>
              <li><Link to="/products">Accessories</Link></li>
            </ul>
          </div>

          <div className="footer-links">
            <h4>About</h4>
            <ul>
              <li><span>Built with React</span></li>
              <li><span>Vite + React Router</span></li>
              <li><span>Frontend Only</span></li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; {new Date().getFullYear()} ShopSphere. All rights reserved.</p>
          <p className="footer-built">Built with React for educational purposes.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
