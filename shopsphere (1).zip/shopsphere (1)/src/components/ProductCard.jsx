import { Link } from 'react-router-dom';

function ProductCard({ product, onAddToCart }) {
  const handleAddToCart = (e) => {
    e.preventDefault();
    onAddToCart(product, 1);
  };

  return (
    <article className="product-card">
      <Link to={`/products/${product.id}`} className="product-card-image-link">
        <div className="product-card-image">
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            onError={(e) => {
              e.target.src = 'https://via.placeholder.com/400x400?text=Product';
            }}
          />
        </div>
      </Link>

      <div className="product-card-body">
        <span className="product-category">{product.category}</span>
        <Link to={`/products/${product.id}`} className="product-name-link">
          <h3 className="product-name">{product.name}</h3>
        </Link>
        <div className="product-rating" aria-label={`Rating: ${product.rating} out of 5`}>
          <span className="stars">{'★'.repeat(Math.floor(product.rating))}{'☆'.repeat(5 - Math.floor(product.rating))}</span>
          <span className="rating-value">{product.rating}</span>
        </div>
        <p className="product-price">${product.price.toFixed(2)}</p>
        <div className="product-card-actions">
          <button
            type="button"
            className="btn btn-primary btn-sm"
            onClick={handleAddToCart}
            aria-label={`Add ${product.name} to cart`}
          >
            Add to Cart
          </button>
          <Link
            to={`/products/${product.id}`}
            className="btn btn-outline btn-sm"
          >
            View Details
          </Link>
        </div>
      </div>
    </article>
  );
}

export default ProductCard;
