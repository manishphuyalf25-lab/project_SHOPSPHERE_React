import { Link } from 'react-router-dom';

function EmptyCart() {
  return (
    <div className="empty-cart">
      <div className="empty-cart-icon">🛒</div>
      <h2>Your cart is empty</h2>
      <p>Looks like you haven't added anything yet.</p>
      <Link to="/products" className="btn btn-primary">
        Continue Shopping
      </Link>
    </div>
  );
}

export default EmptyCart;
