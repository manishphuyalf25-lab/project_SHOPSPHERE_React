import { Link } from 'react-router-dom';

function CartSummary({ cart, showCheckoutButton = true }) {
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const FREE_SHIPPING_THRESHOLD = 100;
  const SHIPPING_COST = 10;
  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_COST;
  const total = subtotal + shipping;

  return (
    <div className="cart-summary">
      <h2 className="summary-title">Order Summary</h2>

      <div className="summary-row">
        <span>Items ({itemCount})</span>
        <span>${subtotal.toFixed(2)}</span>
      </div>

      <div className="summary-row">
        <span>Shipping</span>
        <span>
          {shipping === 0 ? (
            <span className="free-shipping">FREE</span>
          ) : (
            `$${shipping.toFixed(2)}`
          )}
        </span>
      </div>

      {subtotal > 0 && subtotal < FREE_SHIPPING_THRESHOLD && (
        <p className="shipping-note">
          Free shipping on orders over ${FREE_SHIPPING_THRESHOLD}
        </p>
      )}

      <div className="summary-row summary-total">
        <span>Total</span>
        <span>${total.toFixed(2)}</span>
      </div>

      {showCheckoutButton && cart.length > 0 && (
        <Link to="/checkout" className="btn btn-primary btn-block">
          Proceed to Checkout
        </Link>
      )}
    </div>
  );
}

export default CartSummary;

