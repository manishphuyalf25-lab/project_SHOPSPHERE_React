import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';

function Navbar({ cartItemCount }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-brand" onClick={closeMenu}>
          <span className="brand-icon">◈</span>
          <span className="brand-name">ShopSphere</span>
        </Link>

        <button
          className="menu-toggle"
          onClick={toggleMenu}
          aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={isMenuOpen}
        >
          {isMenuOpen ? '✕' : '☰'}
        </button>

        <nav className={`navbar-nav ${isMenuOpen ? 'open' : ''}`}>
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
            onClick={closeMenu}
            end
          >
            Home
          </NavLink>
          <NavLink
            to="/products"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
            onClick={closeMenu}
          >
            Products
          </NavLink>
          <NavLink
            to="/cart"
            className={({ isActive }) => (isActive ? 'nav-link active cart-link' : 'nav-link cart-link')}
            onClick={closeMenu}
          >
            Cart
            {cartItemCount > 0 && (
              <span className="cart-badge" aria-label={`${cartItemCount} items in cart`}>
                {cartItemCount}
              </span>
            )}
          </NavLink>
          <a
            href="https://github.com/Techo-hacks"
            target="_blank"
            rel="noopener noreferrer"
            className="nav-link github-link"
            onClick={closeMenu}
            aria-label="Visit my GitHub profile"
          >
            GitHub
          </a>
        </nav>
      </div>
    </header>
  );
}

export default Navbar;
