function CartItem({ item, onIncrease, onDecrease, onRemove }) {
  const subtotal = item.price * item.quantity;

  return (
    <div className="cart-item">
      <div className="cart-item-image">
        <img
          src={item.image}
          alt={item.name}
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/100x100?text=Product';
          }}
        />
      </div>

      <div className="cart-item-details">
        <h3 className="cart-item-name">{item.name}</h3>
        <p className="cart-item-price">${item.price.toFixed(2)}</p>
      </div>

      <div className="cart-item-quantity">
        <button
          type="button"
          className="qty-btn"
          onClick={() => onDecrease(item.id)}
          aria-label={`Decrease quantity of ${item.name}`}
          disabled={item.quantity <= 1}
        >
          −
        </button>
        <span className="qty-value" aria-label={`Quantity: ${item.quantity}`}>
          {item.quantity}
        </span>
        <button
          type="button"
          className="qty-btn"
          onClick={() => onIncrease(item.id)}
          aria-label={`Increase quantity of ${item.name}`}
        >
          +
        </button>
      </div>

      <div className="cart-item-subtotal">
        <span className="subtotal-label">Subtotal</span>
        <span className="subtotal-value">${subtotal.toFixed(2)}</span>
      </div>

      <button
        type="button"
        className="btn-remove"
        onClick={() => onRemove(item.id)}
        aria-label={`Remove ${item.name} from cart`}
      >
        Remove
      </button>
    </div>
  );
}

export default CartItem;
